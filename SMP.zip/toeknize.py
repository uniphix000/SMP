#! /usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'uniphix'
# print ('****************************to be implemented********************************')

train_data = json.load(open('data/train.json'), encoding='utf8')