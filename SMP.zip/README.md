# SMP2018-ECDT-TASK1
SMP2018-ECDT评测任务1服务模板，具体评测方案请见docx文档。
